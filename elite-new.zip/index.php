<?php
// ... existing code ...

// Include the routes file
include 'routes.php';

// Get the current URI and remove the base directory
$baseDir = '/elite-new';
$uri = str_replace($baseDir, '', parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));

// Debugging: Print the URI
// echo "Current URI: " . $uri;

// Handle the request based on the URI
handleRequest($uri, $routes);

// ... existing code ...
